<?php
sleep(5);
echo rand(1,6);
?>